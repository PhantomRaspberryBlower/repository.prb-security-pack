sudo pkill -f gpsd
